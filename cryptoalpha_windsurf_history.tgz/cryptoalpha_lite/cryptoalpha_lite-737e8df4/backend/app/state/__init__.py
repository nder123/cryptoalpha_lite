"""Application state management components."""
